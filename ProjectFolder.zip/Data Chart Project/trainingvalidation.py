import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.model_selection import  train_test_split
df = pd.read_csv('tappy.csv')
print(df)

x_df = df.drop('Close', axis='columns')
y_df = df.Close 


X_train, X_test, y_train, y_test = train_test_split(x_df, y_df, test_size=0.4, random_state =10)

reg = linear_model.LinearRegression()
reg.fit(X_train, y_train)

prediction_test = reg.predict(X_test)
print(y_test, prediction_test)
print("Mean sq. error between y_test and predicted =", np.mean(prediction_test-y_test)**2)

plt.scatter(prediction_test, prediction_test-y_test)
plt.hlines(y=0, xmin=0, xmax=5)
plt.show()